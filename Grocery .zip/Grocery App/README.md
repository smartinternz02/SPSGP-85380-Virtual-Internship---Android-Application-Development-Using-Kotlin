# Virtual Internship - Android Application Development Using Kotlin MAIN PROJECT 2

## Grocery Android Application

As we can't remember everything, users frequently forget to buy the things they want to buy. However, with the assistance of this app, you can make a list of the groceries you intend to buy so that you don't forget anything.
It is grocery bucket list app which you love to use while shopping.
